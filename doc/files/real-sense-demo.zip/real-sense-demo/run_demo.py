from atom import Element
import msgpack
import cv2
import numpy as np

element = Element("camera")
fourcc = cv2.VideoWriter_fourcc(*'MJPG')
out = cv2.VideoWriter('output.avi',fourcc, 20.0, (640,480))

for i in range(100):
	entries = element.entry_read_n("realsense","color",1)		
	bytes = entries[0]['data']
	np_array = np.fromstring(bytes, np.uint8)
	np_image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
	out.write(np_image)
	if cv2.waitKey(1) & 0xFF == ord('q'):
		break

out.release()



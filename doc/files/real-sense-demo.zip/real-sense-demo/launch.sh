#!/bin/bash

cd /demo
python3 run_demo.py

# TODO: launch your element and anything else needed here.
echo "Hello, world!"
